#ifndef MAP_H
#define MAP_H

void map(char**, int*, int*, int*, int*, int*, int*, int*, int*);
void mapPrint(char**, int*, int*, int*, int*, int*, int*);

#endif