#ifndef RANDOMBOX_H
#define RANDOMBOX_H

void boxLocation(int*, int*, int*, int*, int*, int*, int*, int*);

#endif