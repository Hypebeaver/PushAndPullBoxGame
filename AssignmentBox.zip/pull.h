#ifdef PULL

void pull(int*, int*, int*, int*, int*, int*);

#endif