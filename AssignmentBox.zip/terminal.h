#ifndef TERMINAL_H
#define TERMINAL_H

void disableBuffer();
void enableBuffer();

#endif