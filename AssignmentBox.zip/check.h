#ifndef CHECK_H
#define CHECK_H

int checkRange(int*);
int checkArgument(int*, char*[], int* ,int*, int*, int*, int*, int*);

#endif